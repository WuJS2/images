package com.wujs.service.impl;

import com.wujs.service.Idempotence;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

@Component
public class RedisIdempotence implements Idempotence {
    @Autowired
    private RedisTemplate redisTemplate;

    @Override
    public boolean check(String idempotenceId) {
        return Boolean.TRUE.equals(redisTemplate.hasKey(idempotenceId));
    }

    @Override
    public void record(String idempotenceId) {
        redisTemplate.opsForValue().set(idempotenceId, "1");
    }

    // 还是应该设置一个过期时间，哪怕时间很长也要设置
    @Override
    public void record(String idempotenceId, Integer time) {
        redisTemplate.opsForValue().set(idempotenceId, "1", time, TimeUnit.SECONDS);
    }

    @Override
    public boolean delete(String idempotenceId) {
        return Boolean.TRUE.equals(redisTemplate.delete(idempotenceId));
    }
}