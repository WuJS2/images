package com.wujs.util;

import com.wujs.service.Idempotence;
import org.apache.logging.log4j.util.Base64Util;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.util.UUID;

@Component
public class IdempotenceUtil {
    @Autowired
    private Idempotence idempotence;

    /**
     * 生成幂等号
     *
     * @return
     */
    public String generateId() {
        String uuid = UUID.randomUUID().toString();
        String uId = Base64Util.encode(uuid).toLowerCase();
        idempotence.record(uId, 1800);
        return uId;
    }

    /**
     * 从Header里面获取幂等号
     *
     * @return
     */
    public String getHeaderIdempotenceId() {
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpServletRequest request = attributes.getRequest();
        String idempotenceId = request.getHeader("idempotenceId");
        return idempotenceId;
    }
}