package com.wujs.aop.idempotence;

/**
 * @author WuJS
 * @date 2023/1/13
 */
public class IdempotencyException extends RuntimeException {
    public IdempotencyException() {
        super();
    }

    public IdempotencyException(String message) {
        super(message);
    }

    public IdempotencyException(String message, Throwable cause) {
        super(message, cause);
    }

    public IdempotencyException(Throwable cause) {
        super(cause);
    }
}
