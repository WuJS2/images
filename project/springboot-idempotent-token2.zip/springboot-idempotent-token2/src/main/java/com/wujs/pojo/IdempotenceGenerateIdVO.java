package com.wujs.pojo;

import lombok.Builder;
import lombok.Data;

/**
 * @author WuJS
 * @date 2023/1/13
 */
@Data
@Builder
public class IdempotenceGenerateIdVO {
    private String idempotenceId;
}
