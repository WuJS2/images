package com.wujs.controller;

import com.wujs.pojo.HelloVO;
import com.wujs.service.IdempotenceRequired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author WuJS
 * @date 2023/1/13
 */
@RestController
public class HelloController {
    @RequestMapping("/hello")
    public HelloVO hello() {
        return HelloVO.builder().username("test").msg("xxx").build();
    }

    @IdempotenceRequired
    @RequestMapping("/test")
    public HelloVO test() {
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        return HelloVO.builder().username("test").msg("xxx").build();
    }
}
