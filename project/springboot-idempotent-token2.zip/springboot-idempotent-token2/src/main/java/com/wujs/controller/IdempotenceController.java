package com.wujs.controller;

import com.wujs.pojo.IdempotenceGenerateIdVO;
import com.wujs.util.IdempotenceUtil;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@RestController
@RequestMapping("/idempotence")
public class IdempotenceController {
    @Resource
    IdempotenceUtil idempotenceUtil;

    /**
     * 生成幂等号
     *
     * @return
     */
    @GetMapping("/generateId")
    public IdempotenceGenerateIdVO generateId() {
        String uId = idempotenceUtil.generateId();
        return IdempotenceGenerateIdVO.builder().idempotenceId(uId).build();
    }
}