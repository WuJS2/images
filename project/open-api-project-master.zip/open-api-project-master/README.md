# open-api-project
java版开放接口统一网关鉴权demo项目

open-api-common 公共基础配置

open-api-web 开放接口 web


详细介绍请跳转博客谢谢
https://blog.csdn.net/qq_38011415/article/details/88779364
