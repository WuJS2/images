package com.open.api.enums;

public interface EnumInterface {
    String getCode();

    String getMsg();
}