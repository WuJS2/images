package com.wujs.idempotent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootIdempotentTokenApplicationTests {

    @Test
    void contextLoads() {
    }

}
