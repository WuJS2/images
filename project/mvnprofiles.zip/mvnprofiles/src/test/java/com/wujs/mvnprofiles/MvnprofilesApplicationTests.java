package com.wujs.mvnprofiles;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MvnprofilesApplicationTests {

    @Value("${profile}")
    private String profile;

    @Test
    void contextLoads() {
        System.out.println(profile);
    }

}
